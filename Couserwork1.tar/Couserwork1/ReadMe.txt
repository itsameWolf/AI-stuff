all the code has been written and tested for python 3.7.1 
numpy, pyplot, seaborn and pandas have been used while developinfg this code, they are all available in the base anaconda enviroment.
all the function for perceptron learing and evaluation are written in Perceptron.py
each question has code relative to answer saved in the respective file, question file has been split in 3 files, one for each classifier